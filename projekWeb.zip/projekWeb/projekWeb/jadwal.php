<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <style>
        * {
            align-items: center;
            text-align: center;
            box-sizing: border-box;
        }

        h1 {
            color: green;
        }

        h3 {
            margin-top: 300px;
            color: blue;

        }

        h2 {
            margin-top: 200px;
            color: blue;
            opacity: 0;


        }

        #myInput {
            background-image: url('/css/searchicon.png');
            background-position: 10px 10px;
            background-repeat: no-repeat;
            width: 25%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }
        #myInput1 {
            background-image: url('/css/searchicon.png');
            background-position: 10px 10px;
            background-repeat: no-repeat;
            width: 25%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }
        #myInput2 {
            background-image: url('/css/searchicon.png');
            background-position: 10px 10px;
            background-repeat: no-repeat;
            width: 25%;
            font-size: 16px;
            padding: 12px 20px 12px 40px;
            border: 1px solid #ddd;
            margin-bottom: 12px;
        }

        #myTable {
            border-collapse: collapse;
            width: 100%;
            border: 1px solid #ddd;
            font-size: 18px;
        }

        #myTable th,
        #myTable td {
            text-align: left;
            padding: 12px;
        }

        #myTable tr {
            border-bottom: 1px solid #ddd;
        }

        #myTable tr.header,
        #myTable tr:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>

<body>

    <?php
    require 'vendor/autoload.php';

    $filename = "file/jadwalKuliah.xlsx";
    if (file_exists($filename)) {
    ?>
        <h1>Jadwal Kelas</h1>
        <input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by Dosen/matkul/ruangan..."  >
        <table class="table xs-1 table-striped-columns m-5 p-5 " id="myTable">
            <thead class=" thead-dark">
                <tr>
                    <td>Hari</td>
                    <td>Slot Waktu</td>
                    <td>Dosen</td>
                    <td>Ruang</td>
                    <td>Kelas</td>
                    <td>Mata Kuliah</td>
                    <td>JJ</td>
                    <td>Tahun Ajaran</td>
                    <td>Semester</td>
                </tr>
            </thead>
            <tbody>
                <?php
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile("file/jadwalKuliah.xlsx");
                $spreadsheet = $reader->load("file/jadwalKuliah.xlsx");
                $sheetData = $spreadsheet->getActiveSheet()->toArray();

                for ($i = 2; $i < count($sheetData); $i++) {
                    $hari = $sheetData[$i]['1'];
                    $slotwaktu = $sheetData[$i]['2'];
                    $dosen = $sheetData[$i]['3'];
                    $ruang = $sheetData[$i]['4'];
                    $kelas = $sheetData[$i]['5'];
                    $matkul = $sheetData[$i]['6'];
                    $jj = $sheetData[$i]['7'];
                    $tahunajaran = $sheetData[$i]['8'];
                    $semester = $sheetData[$i]['9'];
                ?>

                    <tr>
                        <td><?= $hari; ?></td>
                        <td><?= $slotwaktu; ?></td>
                        <td><?= $dosen; ?></td>
                        <td><?= $ruang; ?></td>
                        <td><?= $kelas; ?></td>
                        <td><?= $matkul; ?></td>
                        <td><?= $jj; ?></td>
                        <td><?= $tahunajaran; ?></td>
                        <td><?= $semester; ?></td>

                    </tr>

                <?php
                }
            } else { ?>

                <h3>Jadwal Belum di Upload</h3>
            <?php
            }

            ?>
            <script>
                function myFunction() {
                    var input, filter, table, tr, td, td1, td2, i, txtValue, tv1,tv2;
                    input = document.getElementById("myInput");
                    filter = input.value.toUpperCase();
                    table = document.getElementById("myTable");
                    tr = table.getElementsByTagName("tr");
                    for (i = 0; i < tr.length; i++) {
                        td = tr[i].getElementsByTagName("td")[2] ;
                        td1 = tr[i].getElementsByTagName("td")[3] ;
                        td2 = tr[i].getElementsByTagName("td")[5] ;
                        if (td||td1||td2) {
                            txtValue = td.textContent || td.innerText;
                            tv1 = td1.textContent || td1.innerText;
                            tv2 = td2.textContent || td2.innerText;
                            if (txtValue.toUpperCase().indexOf(filter) > -1 ||tv1.toUpperCase().indexOf(filter) > -1||tv2.toUpperCase().indexOf(filter) > -1) {
                                tr[i].style.display = "";
                            } 
                            else {
                                tr[i].style.display = "none";
                            }
                            
                        }

                    }
                    
                }
            </script>
</body>

</html>