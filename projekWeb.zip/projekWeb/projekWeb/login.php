<!DOCTYPE html>
<?php
    session_start();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

    <?php
        if(isset($_POST['prosesLogin'])){
            $user=$_POST['user'];
            $pass=$_POST['pass'];

            if($user=='Robert' AND $pass=='admin'){
                $_SESSION['akses']=$user;
                header("location:admin.php");
                
            }
            else{
                echo "<script> alert('Tidak Terdaftar!!');
                window.location.href='login.php';
                </script>";
            }   
        }

        else{
    ?>
    <form method="post" action="<?php $_SERVER ['PHP_SELF']; ?>">
        <table>
            <tr>
            <h1>Login</h1>
            </tr>
            <tr>
                <td>Username:</td>
                <td><input type="text" name="user"></td>
            </tr>
            <tr>
                <td>Password:</td>
                <td><input type="password" name="pass"></td>
            </tr>
            <tr>
                <td colspan="2"><button type="submit" name="prosesLogin">Login</button></td>
            </tr>
        </table>
    </form>
    <?php
        }   
    ?>
    
</body>
</html>