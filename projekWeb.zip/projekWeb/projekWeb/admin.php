<?php
session_start();
if(empty($_SESSION['akses'])){
    echo "
        <script>
        alert ('Mohon Login...')
        window.location.href='Login.php';
        </script>
    ";
}


require 'function.php';
//tombol ditekan
if (isset($_POST["submit"])) {

    $fileExcel = upload();
    if (!$fileExcel) {
        echo "<script>
        alert('gagal ges!');
        document.location.href('admin2.php');
        </script>";
    } else {
        echo "<script>
        alert('berhasil ges!');
        document.location.href('jadwal.php');
        </script>";
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
</head>

<body>
<nav>
    <ul>
        <li class="left">Selamat datang, <?php echo $_SESSION['akses']?></li>
        <li class="left"><a href="keluar.php">Log Out</a>
    </ul>
</nav>

    <form method="POST" enctype="multipart/form-data" class="row g-2 m-5">
        <div class="col-auto">
            <input class="form-control" type="file" id="excel" name="excel">
        </div>
        <div class="col-auto">
            <button type="submit" name="submit">Upload</button>
        </div>

        

    </form>




</body>

</html>