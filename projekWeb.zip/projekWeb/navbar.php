<nav>
    <div class="navbar">
        <i class='bx bx-menu'></i>
        <div class="logo">
            <a href="#home">Jadwal TI-CCIT 5</a>
        </div>
        <div class="nav-links">
            <div class="sidebar-logo">
                <span class="logo_name">
                    E-Learning PNJ
                </span>
                <i class='bx bx-x'></i>
            </div>
            <ul class="links">
                <li>
                    <a href="main.php">Home</a>
                </li>


            </ul>
        </div>
        <!-- Search Box -->
        <div class="iconlogo">

            <div class="user">
                <i class='bx bx-user'></i>
            </div>
            <div class="darkmode">
                <i class='bx bx-moon'></i>
            </div>
        </div>
        <form action="login.php" class="login-form">
            <input type="submit" value="Admin" class="btn">
        </form>
    </div>
</nav>