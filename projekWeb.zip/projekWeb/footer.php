<section class="footer">
    <div class="box-container">
        <div class="box">

            <h3>PNJ <i class="fas fa-graduation-cap"></i></h3>
            <p>Politeknik Negeri Jakarta atau biasa disingkat PNJ adalah salah satu politeknik terbaik di Indonesia. PNJ ini terletak di Jl. Prof. DR. G.A. Siwabessy, Kukusan, Kecamatan Beji, Kota Depok, Jawa Barat 16424.</p>
            <div class="share">
                <a href="https://www.facebook.com/PoliteknikNegeriJakartaOfficial/" class="fab fa-facebook-f"></a>
                <a href="https://twitter.com/BEMPNJ/status/1383768773379776517" class="fab fa-twitter"></a>
                <a href="https://www.instagram.com/PoliteknikNegeriJakarta/"  class="fab fa-instagram"></a>
                
            </div>
        </div>

        <div class="box">
            <h3>contact info</h3>
            <a href="#" class="links text-decoration-none"> <i class="fas fa-phone"></i> +62 821-1214-4860 </a>
            <a href="#" class="links text-decoration-none"> <i class="fas fa-tty"></i> (021)-7270036 </a>
            <a href="#" class="links text-decoration-none"> <i class="fas fa-envelope"></i> akademik@pnj.ac.id </a>
            <a href="#" class="links text-decoration-none"> <i class="fas fa-map-marker-alt"></i> Depok, Jawa Barat 16411 </a>
        </div>



        <div class="box">
            <h3>newsletter</h3>
            <p>subscribe for latest updates</p>
            <input type="email" placeholder="your email" class="email" />
            <input type="submit" value="subscribe" class="btn" />

        </div>
    </div>

    <div class="credit">created as a <span> mid-semester exam assignment </span> | all rights reserved to Team 2</div>
</section>