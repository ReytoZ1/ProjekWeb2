/*Navbar Start*/
let navbar = document.querySelector(".navbar");

// Search Menu ,Login and Darkmode

let loginShow = document.querySelector(".user .bx-user");
let darktheme = document.querySelector(".darkmode .bx-moon");

loginShow.addEventListener("click",()=>{
  navbar.classList.toggle("showlogin");
})
darktheme.addEventListener("click", ()=>{
  document.body.classList.toggle("dark-theme");
  if(document.body.classList.contains("dark-theme")){
   darktheme.classList.replace("bx-moon","bx-sun");
}
else{
    darktheme.classList.replace("bx-sun","bx-moon");
}
})




// Search Menu, Login and Darkmode end




// Menu Responsive
let openMenu = document.querySelector(".navbar .bx-menu");
let closeMenu = document.querySelector(".nav-links .bx-x");
let navLinks = document.querySelector(".nav-links");
let Links = document.querySelector(".links");

openMenu.addEventListener("click", ()=>{
navLinks.style.left = "0";
navLinks.style.display = "block";
})
closeMenu.addEventListener("click", ()=>{
    navLinks.style.left = "-100%";
    
    })

    


/*Navbar End*/


/*Pop Up Start*/
// const popup = document.querySelector('.popup');
// const body = document.querySelector('body');
// const close = document.querySelector('.close');
// window.onload = function(){
//     setTimeout(function(){
//         popup.style.display = "block"

//     },500)
// }
// close.addEventListener('click', () =>{
//     popup.style.display = "none"
// })

/*Pop Up End*/


/*Swiper Start*/
var swiper = new Swiper(".product-slider", {
  loop: true,
  spaceBetween: 20,
  autoplay: {
    delay: 2000,
    disableOnInteraction: false,
  },
  centeredSlides: true,
  breakpoints: {
    0: {
      slidesPerView: 1,
    },
    768: {
      slidesPerView: 2,
    },
    1020: {
      slidesPerView: 3,
    },
  },
});
window.onscroll = () => {

  navbar.classList.remove("active");
};

/*Swiper End*/

