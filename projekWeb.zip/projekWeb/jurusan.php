<section class="jurusan" id="jurusan">
    <h1 class="heading">Jurusan <span>PNJ</span></h1>


    <div class="swiper product-slider">
        <div class="swiper-wrapper">
            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/TGP.png" alt="">
                    <h3>TGP</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                  
                </div>
            </div>

            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/TIK.png" alt="">
                    <h3>Teknik Informatika dan Komputer</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>

                   
                </div>
            </div>

            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/AK.png" alt="">
                    <h3>Akuntansi</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                    
                </div>
            </div>

            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/an.png" alt="">
                    <h3>Administrasi Niaga</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                    
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/el.png" alt="">
                    <h3>Teknik Elektro</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                   
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/mc.png" alt="">
                    <h3>Teknik Mesin</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                   
                </div>
            </div>
            <div class="swiper-slide box">
                <div class="price">

                    <img src="img/sp.png" alt="">
                    <h3>Teknik Sipil</h3>

                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star-half-alt"></i>
                    </div>

                   
                </div>
            </div>


        </div>


</section>