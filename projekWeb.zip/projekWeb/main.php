<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title> E-Learning PNJ</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">



    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <!-- Swiper JS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        <?php include "style.css" ?>
    </style>
</head>

<body>


    <!-- Navbar Start -->
    <?php include("navbar.php") ?>
    <!-- Navbar End -->

    <!-- Home page Start -->
    <section class="home" id="home">
        <div class="content">
            <h3>Jadwal <span>Kelas</span> </h3>
            <p> TI-CCIT 5 2022-2023</p>
            <a href="jadwal.php" class="btn">Lihat disini </a>
        </div>
    </section>
    <!-- Home Page End -->



    <!-- jurusan section starts  -->
    <?php include("jurusan.php") ?>
    <!-- jurusan section ends -->

    <!-- Footer Start -->
    <?php include("footer.php") ?>
    <!-- Footer End -->

    <!-- Swiper JS -->
    <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
    <!-- Navbar JS -->
    <script src="function.js"></script>

</body>

</html>