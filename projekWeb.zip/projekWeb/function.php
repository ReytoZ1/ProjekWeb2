
<?php

require 'vendor/autoload.php';

function upload()
{
    $namaFile = $_FILES['excel']['name'];
    $error = $_FILES['excel']['error'];
    $tmpName = $_FILES['excel']['tmp_name'];



    //cek apakah diupload apa tidak
    if ($error === 4) {
        echo "<script>
        alert('Masukkan File terlebih dahulu!');
       
        </script>";
        return false;
    }

    //cek ekstensi
    $ekstensiFileValid = ['xls', 'xlsx', 'csv'];
    $ekstensiFile = explode('.', $namaFile);
    $ekstensiFile = strtolower(end($ekstensiFile));

    if (!in_array($ekstensiFile, $ekstensiFileValid)) {
        echo "<script>
        alert('Hanya bisa file excel. File yang anda masukkan $ekstensiFile !');
       
        </script>";
        return false;
    }

    move_uploaded_file($tmpName, 'file/jadwalKuliah.xlsx' . $namaFile);

    return $namaFile;
}
