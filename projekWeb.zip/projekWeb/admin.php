<?php
session_start();
if (empty($_SESSION['akses'])) {
    echo "
        <script>
        alert ('Mohon Login...')
        window.location.href='Login.php';
        </script>
    ";
}


require 'function.php';
//tombol ditekan
if (isset($_POST["submit"])) {

    $fileExcel = upload();
    if ($fileExcel) {
        echo "<script>
        alert('Berhasil Upload!');
        
        </script>";
    }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <style>
        .navbar {
            background: #8ec3b0;
        }

        body {
            background: #bcead5;
        }

        .nav-link,
        .navbar-brand {
            color: whitesmoke;
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg shadow-sm fixed-top ">
        <div class="container">
            <a class="navbar-brand text-start" href="#"> E-learning PNJ</a>

            <div class="collapse navbar-collapse " id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link " href="#home">Selamat datang, <?php echo $_SESSION['akses'] ?></a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="keluar.php">Logout</a>
                    </li>


                </ul>
            </div>

        </div>
        </div>
    </nav>
    <div class="container mt-5 ">

        <div class="d-flex justify-content-center">
            <form method="POST" enctype="multipart/form-data" class="row g-2 mt-5  ">
                <div class="col-auto align-middle ">
                    <input class="form-control " type="file" id="excel" name="excel">
                </div>
                <div class="col">
                    <button type="submit" name="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>








</body>
<script>
    const alertPlaceholder = document.getElementById('liveAlertPlaceholder')

    const alert = (message, type) => {
        const wrapper = document.createElement('div')
        wrapper.innerHTML = [
            `<div class="alert alert-${type} alert-dismissible" role="alert">`,
            `   <div>${message}</div>`,
            '   <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>',
            '</div>'
        ].join('')

        alertPlaceholder.append(wrapper)
    }

    const alertTrigger = document.getElementById('liveAlertBtn')
    if (alertTrigger) {
        alertTrigger.addEventListener('click', () => {
            alert('Nice, you triggered this alert message!', 'success')
        })
    }
</script>
<script src="function.js"></script>

</html>