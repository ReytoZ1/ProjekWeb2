<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jadwal</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" />
    <!-- Swiper JS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <style>
        h1 {
            display: none;
        }
    </style>
    <style>
        <?php include "style.css" ?>
    </style>
</head>

<body>
    <?php include("navbar.php") ?>
    <div class="container mt-5 ">
        <div class="row mt-5">

            <?php
            require 'vendor/autoload.php';

            $filename = "file/jadwalKuliah.xlsx";
            if (file_exists($filename)) {
            ?>
                <h1 class="m-5">Jadwal Kelas</h1>

                <input class="center" type="text" id="myInput" onkeyup="myFunction()" placeholder="Search by Dosen/matkul/ruangan...">
                <table class="table xs-1 table-hover m-5 p-5 " id="myTable">
                    <thead class=" thead-dark">
                        <tr>
                            <td>Hari</td>
                            <td>Slot Waktu</td>
                            <td>Dosen</td>
                            <td>Ruang</td>
                            <td>Kelas</td>
                            <td>Mata Kuliah</td>
                            <td>JJ</td>
                            <td>Tahun Ajaran</td>
                            <td>Semester</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile("file/jadwalKuliah.xlsx");
                        $spreadsheet = $reader->load("file/jadwalKuliah.xlsx");
                        $sheetData = $spreadsheet->getActiveSheet()->toArray();

                        for ($i = 2; $i < count($sheetData); $i++) {
                            $hari = $sheetData[$i]['1'];
                            $slotwaktu = $sheetData[$i]['2'];
                            $dosen = $sheetData[$i]['3'];
                            $ruang = $sheetData[$i]['4'];
                            $kelas = $sheetData[$i]['5'];
                            $matkul = $sheetData[$i]['6'];
                            $jj = $sheetData[$i]['7'];
                            $tahunajaran = $sheetData[$i]['8'];
                            $semester = $sheetData[$i]['9'];
                        ?>

                            <tr>
                                <td><?= $hari; ?></td>
                                <td><?= $slotwaktu; ?></td>
                                <td><?= $dosen; ?></td>
                                <td><?= $ruang; ?></td>
                                <td><?= $kelas; ?></td>
                                <td><?= $matkul; ?></td>
                                <td><?= $jj; ?></td>
                                <td><?= $tahunajaran; ?></td>
                                <td><?= $semester; ?></td>

                            </tr>

                        <?php
                        }
                    } else { ?>

                        <h3>Jadwal Belum di Upload</h3>
                    <?php
                    }

                    ?>
        </div>
    </div>

    <script>
        function myFunction() {
            var input, filter, table, tr, td, td1, td2, i, txtValue, tv1, tv2;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            table = document.getElementById("myTable");
            tr = table.getElementsByTagName("tr");
            for (i = 0; i < tr.length; i++) {
                td = tr[i].getElementsByTagName("td")[2];
                td1 = tr[i].getElementsByTagName("td")[3];
                td2 = tr[i].getElementsByTagName("td")[5];
                if (td || td1 || td2) {
                    txtValue = td.textContent || td.innerText;
                    tv1 = td1.textContent || td1.innerText;
                    tv2 = td2.textContent || td2.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1 || tv1.toUpperCase().indexOf(filter) > -1 || tv2.toUpperCase().indexOf(filter) > -1) {
                        tr[i].style.display = "";
                    } else {
                        tr[i].style.display = "none";
                    }

                }

            }

        }
    </script>
</body>
<script src="function.js"></script>

</html>